import 'package:flutter/material.dart';

void main() {
  runApp(const ConnectXApp());
}

class ConnectXApp extends StatelessWidget {
  const ConnectXApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: Text('ConnectX')),
        body: Center(child: Text('مرحبًا بك في ConnectX!')),
      ),
    );
  }
}